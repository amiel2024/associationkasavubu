<?php
    include("header.php")
    ?>


        <main>
            <!-- slider start -->
            <section class="slider-area">
                <div class="slider-active">
                    <div class="single-slider slider-height pos-rel d-flex align-items-center" data-background="img/bg/slider-bg-01.jpg">
                        <div class="container">
    <style>
        .slider-content h5 {
            color: #ffcc2a; /* orange pour Jaguar Group Holding */
        }

        .slider-content h1,
        .slider-content p {
            color: #ffffff; /* blanc pour le reste du texte */
        }
    </style>
    <div class="row">
        <div class="col-xl-7 col-lg-8">
            <div class="slider-content">
                <h5 data-animation="fadeInUp" data-delay=".2s">Mate Engineering</h5>
                <h1 data-animation="fadeInUp" data-delay=".4s">Un groupe de sociétés <span>.</span></h1>
                <p data-animation="fadeInUp" data-delay=".6s">
                    Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction.
                </p>
                <div class="slider-btn">
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="contact.php">Contacter</a>
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="about.php">Découvrir</a>
                </div>
            </div>
        </div>
    </div>
</div>
                    </div>
                    <div class="single-slider slider-height pos-rel d-flex align-items-center" data-background="img/bg/slider-bg-03.jpg">
                        <div class="container">
                            <div class="row">
        <div class="col-xl-7 col-lg-8">
            <div class="slider-content">
                <h5 data-animation="fadeInUp" data-delay=".2s">Mate Engineering</h5>
                <h1 data-animation="fadeInUp" data-delay=".4s">Un groupe de sociétés <span>.</span></h1>
                <p data-animation="fadeInUp" data-delay=".6s">
                     Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction.
                </p>
                <div class="slider-btn">
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="contact.php">Contacter</a>
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="about.php">Découvrir</a>
                </div>
            </div>
        </div>
    </div>
                        </div>
                    </div>

                    <div class="single-slider slider-height pos-rel d-flex align-items-center" data-background="img/bg/slider-bg-02.jpg">
                        <div class="container">
                             <div class="row">
        <div class="col-xl-7 col-lg-8">
            <div class="slider-content">
                <h5 data-animation="fadeInUp" data-delay=".2s">Mate Engineering</h5>
                <h1 data-animation="fadeInUp" data-delay=".4s">Expertise démontrée <span>.</span></h1>
                <p data-animation="fadeInUp" data-delay=".6s">
                    Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction.
                </p>
                <div class="slider-btn">
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="contact.php">Contacter</a>
                    <a data-animation="fadeInLeft" data-delay=".6s" class="thm-btn" href="about.php">Découvrir</a>
                </div>
            </div>
        </div>
    </div>
                        </div>
                    </div>





                </div>
            </section>
            <!-- slider end --> 

            <!-- about start -->
            
            <section class="about-area pb-90 pt-5" id="about">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="about-tab">
                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <a class="nav-item nav-link active" id="nav-vision-tab" data-toggle="tab" href="#nav-vision" role="tab" aria-controls="nav-vision" aria-selected="true">
                                            <div class="about-tab-item d-flex align-items-center">
                                                <div class="about-tab-thumb mr-3">
                                                    <i class="fas fa-eye" style="font-size: 48px; color: #ffc107;"></i> </div>
                                                <div class="about-tab-content">
                                                    <h4 style="margin: 0; font-weight: 600; color: #222;">Notre Vision</h4>
                                                    <p style="margin: 0; font-size: 0.9rem; color: #666;">Construire un système d'ingénierie innovat pour l'Afrique</p>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="nav-item nav-link" id="nav-mission-tab" data-toggle="tab" href="#nav-mission" role="tab" aria-controls="nav-mission" aria-selected="false">
                                            <div class="about-tab-item d-flex align-items-center">
                                                <div class="about-tab-thumb mr-3">
                                                    <i class="fas fa-bullseye" style="font-size: 48px; color: #ffc107;"></i> </div>
                                                <div class="about-tab-content">
                                                    <h4 style="margin: 0; font-weight: 600; color: #222;">Notre Mission</h4>
                                                    <p style="margin: 0; font-size: 0.9rem; color: #666;">Développer des filiales solides et complémentaires dans des secteurs clés.</p>
                                                </div>
                                            </div>
                                        </a>
                                        <a class="nav-item nav-link" id="nav-valeurs-tab" data-toggle="tab" href="#nav-valeurs" role="tab" aria-controls="nav-valeurs" aria-selected="false">
                                            <div class="about-tab-item d-flex align-items-center">
                                                <div class="about-tab-thumb mr-3">
                                                    <i class="fas fa-handshake" style="font-size: 48px; color: #ffc107;"></i> </div>
                                                <div class="about-tab-content">
                                                    <h4 style="margin: 0; font-weight: 600; color: #222;">Nos Valeurs</h4>
                                                    <p style="margin: 0; font-size: 0.9rem; color: #666;">Excellence, Intégrité, Responsabilité, Innovation.</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </nav>

                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade" id="nav-01" role="tabpanel" aria-labelledby="nav-01-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos !</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>

                                                        <p>Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un 
                                                            large éventail d’activités allant de la maintenance à la construction. Elle intervient principalement 
                                                            dans les domaines de l’électricité, de la mécanique, de l’automation, 
                                                            de la construction, ainsi que dans la fourniture d’équipements industriels.</p>
                              
                                                               <ul class="about-info mt-30 mb-30">
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Equipe dynamique</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Expérience démontrée</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Qualité guarantie</h5>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <div class="about-btn pt-20">
                                                            <a href="about.php" class="thm-btn">Lire plus</a>
                                                   
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>10<span>+</span></h1>
                                                            <h5>Années</h5>
                                                            <h3>d'Expérience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade show active" id="nav-02" role="tabpanel" aria-labelledby="nav-02-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos !</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>
                                                        <p>Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail 
                                                            d’activités allant de la maintenance à la construction. Elle intervient principalement dans les domaines de l’électricité, de
                                                             la mécanique, de 
                                                            l’automation, de la construction, ainsi que dans la fourniture d’équipements industriels.</p>
                                                    
                                                        <ul class="about-info mt-30 mb-30">
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Equipe dynamique</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Expérience démontrée</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Qualité guarantie</h5>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <div class="about-btn pt-20">
                                                            <a href="about.php" class="thm-btn">Découvrir</a>
                                                   
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>10<span>+</span></h1>
                                                            <h5>années</h5>
                                                            <h3>d'expérience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-03" role="tabpanel" aria-labelledby="nav-03-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A Propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>

                                                        <p>JAGUAR GROUP HOLDING est un conglomérat international structuré autour 
                                                            de plusieurs pôles d’activité stratégiques, incarnant puissance, innovation
                                                             et excellence. Avec une vision à long terme et un engagement fort envers la
                                                              performance durable, le groupe fédère des filiales spécialisées, chacune leader
                                                               dans son secteur.</p>

                                                     
                                                               <ul class="about-info mt-30 mb-30">
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Equipe dynamique</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Expérience démontrée</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Qualité guarantie</h5>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <div class="about-btn pt-20">
                                                            <a href="about.php" class="thm-btn">Découvrir</a>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>29<span>+</span></h1>
                                                            <h5>Years</h5>
                                                            <h3>of Experience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about end -->

            <!-- services start -->
            <section class="services-area gray-bg pt-120 pb-90">
                <div class="container">
                    <div class="section-title text-center">
                        <div class="border-title">
                            <h1>Services</h1>
                        </div>
                        <h5>Nos </h5>
                        <h2>Services</h2>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                  <h2>Maintenance des équipements électriques</h2>
                                    <p>La vente de services de maintenance des équipements électriques, automation et mécaniques.</p>


                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box active text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Construction</h2>
                                    <p>La construction, la réhabilitation des bâtiments et la fourniture des équipements industriels.</p>


                                    <a class="sevices-btn" href="services.php">Lire plus<i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Electricté des batiments</h2>
                                    <p>L’électricité de bâtiments et industrielle, et la mise en place du système électronique de sécurisation de maisons, 
                                        sites et entreprises.</p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Débroussaillage des lignes électriques</h2>
                                    <p>  Les lignes haute et basse tension, 
 Les servitudes électriques en milieux urbains et ruraux, 
 Les zones sensibles aux risques d’incendie ou de coupure de courant</p>
</p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2> Le froid en général</h2>
                                    <p>Installation de systèmes frigorifiques : chambres froides, vitrines réfrigérées, congélateurs industriels, etc.

Entretien et dépannage : maintenance préventive et corrective pour garantir la performance et la durabilité de vos équipements.</p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Flottation des minerais</h2>
                                    <p>	L'entretien des équipements de concassage et flottation des minerais. Diagnostic et intervention rapide pour réduire les arrêts de production et maximiser le rendement des installations. </p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Montage des meubles</h2>
                                    <p>La fourniture des bureaux et montage des meubles. Mobilier de qualité : bureaux, chaises, armoires, tables de réunion, rangements, etc.

Montage sur site : assemblage rapide et soigné, avec respect des plans et consignes techniques.</p>
</p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Fourniture des matériels électriques</h2>
                                    <p>	La vente et la fourniture des matériels électriques. Fourniture rapide : disponibilité constante, livraison sur site, et accompagnement dans le choix des équipements.

Conseil technique : assistance pour garantir la conformité.</p>
</p>
                                    <a class="sevices-btn" href="services.php">Lire plus <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </section>
            <!-- services end -->

            




            <!-- testimonial start -->
            <section class="testimonial-area">
                <div class="container-fluid">
                    <div class="row no-gutters">
                        <div class="col-xl-6">
                            <div class="counter-left counter-height pt-125 pb-125" data-background="img/bg/counter-bg.jpg">
                                <div class="counter-content">
                                    <ul>
                                        <li>
                                            <div class="counter-box">
                                                <h1><span>728</span>+</h1>
                                                <div class="counter-right-text">
                                                    <p>Projets</p>
                                                    <p><span> réalisés</span></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="counter-box">
                                                <h1><span>1300</span>+</h1>
                                                <div class="counter-right-text">
                                                    <p>Clients</p>
                                                    <p><span>satisfaits</span></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="counter-box">
                                                <h1><span>29</span>+</h1>
                                                <div class="counter-right-text">
                                                    <p>Projets</p>
                                                    <p><span>actifs</span></p>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="counter-box">
                                                <h1><span>105</span>+</h1>
                                                <div class="counter-right-text">
                                                    <p>Consultants</p>
                                                    <p><span></span></p>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="testimonial-right testimonial-height" data-background="img/bg/testimonial-bg.jpg">
                                <div class="testimonial-active owl-carousel">
                                    <div class="testimonial-single text-center">
                                        <div class="testimonial-thumb">
                                            
                                        </div>
                                        <div class="testimonial-text">
                                           
                                            <p> Rejoignez une dynamique de puissance et de progrès. Grâce à sa diversité sectorielle , Mate Engineering offre un écosystème unique capable d’accompagner la croissance économique sur plusieurs fronts.

                                                Nous croyons à la force du travail collaboratif. C’est pourquoi nous nous entourons de partenaires stratégiques qui partagent nos valeurs et notre exigence de qualité. Ensemble, nous construisons des solutions innovantes et durables pour répondre aux besoins spécifiques de chaque client.
</p>
                                        </div>
                                    </div>
                                   
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- testimonial end -->

            
            <!-- Blog start -->
            <section class="blog-area gray-bg pt-120 pb-90">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog01.jpg" alt="image_not_found">
                                </div>
                               
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog02.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog03.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </section>
            <!-- Blog end -->


            

            <!-- pourquoi nous choisir start -->
            <section class="feature-area pt-120 pb-120 bg-white" id="pourquoi-nous-choisir">
            <div class="container">
                <!-- Titre principal -->
                <div class="section-title text-center mb-5">
                <h2 class="fw-bold text-dark">Pourquoi choisir Mate Engineering ?</h2>
                <p class="mt-3 fs-5 text-muted">
                    La force d’un groupe. La vision d’un avenir durable.
                </p>
                <div class="divider mx-auto mb-4" style="width: 60px; height: 4px; background-color: #007bff; border-radius: 2px;"></div>
                </div>

                <!-- Paragraphe introductif -->
                <div class="row justify-content-center mb-5">
                <div class="col-lg-10">
                    <div class="bg-light p-4 p-md-5 rounded shadow-sm">
                    <p class="text-center fs-5 text-muted">
                        Choisir <strong>MATE Engineering</strong>, c’est s’associer à un conglomérat <strong>ambitieux, solide et tourné vers l’avenir</strong>.
                    </p>
                    </div>
                </div>
                </div>

                <!-- Avantages (cartes) -->
                <div class="row">
                <!-- 1. Vision stratégique -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-project-diagram fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Une vision stratégique et intégrée</h4>
                    <p>
                        Une gouvernance claire et un pilotage rigoureux : chaque filiale agit de façon autonome mais en cohérence avec l’ensemble pour favoriser une croissance durable.
                    </p>
                    </div>
                </div>

                <!-- 2. Diversification sectorielle -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-th-large fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Diversification sectorielle</h4>
                    <p>
                        Industrie, logistique, agriculture, sécurité… Une couverture multisectorielle qui assure résilience et croissance, face aux fluctuations économiques.
                    </p>
                    </div>
                </div>

                <!-- 3. Innovation et excellence -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-cogs fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Innovation & excellence</h4>
                    <p>
                        Une recherche constante de performance et d’innovation technologique pour offrir des services conformes aux standards internationaux.
                    </p>
                    </div>
                </div>

                <!-- 4. Engagement et impact -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-hand-holding-heart fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Engagement local & impact social</h4>
                    <p>
                        Création d’emplois, formation locale, soutien aux chaînes de valeur : un ancrage fort au service du développement des territoires.
                    </p>
                    </div>
                </div>

                <!-- 5. Partenaire fiable -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-handshake fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Partenaire fiable et ambitieux</h4>
                    <p>
                        Confiance, transparence, responsabilité : des valeurs fortes pour des relations durables avec nos clients, partenaires et investisseurs.
                    </p>
                    </div>
                </div>

                <!-- 6. Vision panafricaine -->
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="feature-single text-center mb-30 p-4 shadow-sm bg-light rounded h-100">
                    <div class="mb-3">
                        <i class="fas fa-globe-africa fa-3x text-dark"></i>
                    </div>
                    <h4 class="fw-bold">Vision panafricaine</h4>
                    <p>
                        Une ambition claire : porter la transformation économique à l’échelle du continent africain et au-delà.
                    </p>
                    </div>
                </div>
                </div>

                
            </div>
            </section>
            <!-- pourquoi nous choisir end -->


            <!-- Blog start -->
            <section class="blog-area gray-bg pt-120 pb-90">
                <div class="container">
                    <div class="row">
                        
                        
                        
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog04.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog05.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog06.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog07.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog08.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="single-blog mb-30">
                                <div class="blog-thumb">
                                    <img src="img/blog/blog04.jpg" alt="image_not_found">
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </section>
            <!-- Blog end -->

            
          

            <!-- contact start -->
            <section class="contact-area pt-120 pb-120">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-5 col-lg-5 col-md-12">
                            <div class="contact-left">
                                <div class="contact-thumb-left">
                                    <img src="img/bg/contact-bg.jpg" alt="image_not_found">
                                    <div class="contact-shape"></div>
                                </div>
                                <div class="contact-thumb-right">
                                    <img src="img/bg/contact-bg-02.jpg" alt="image_not_found">
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-7 col-lg-7 col-md-12">
                            <div class="contact-right">
                                <div class="border-title-2">
                                    <h1>Devis</h1>
                                </div>
                                <div class="about-title mb-20">
                                    <h5>Besoin de d'infos?</h5>
                                    <h2>Contactez - nous au plus vite <span>.</span></h2>
                                </div>
                                <form action="#">
                                    <div class="row">
                                        <div class="col-xl-6 col-lg-12">
                                            <div class="text-box">
                                                <span><i class="far fa-user"></i></span>
                                                <input type="text" placeholder="Nom complet"> 
                                            </div>
                                            
                                        </div>
                                        <div class="col-xl-6 col-lg-12">
                                            <div class="text-box">
                                                <span><i class="far fa-envelope"></i></span>
                                                <input type="email" placeholder="E-mail">
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="text-box">
                                                <span><i class="fas fa-arrow-right"></i></span>
                                                <input type="text" placeholder="Sujet">
                                            </div>
                                        </div>
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="message-box">
                                                <span><i class="far fa-edit"></i></span>
                                                <textarea name="message" cols="30" rows="10" placeholder="Your Massage"></textarea>
                                                <button class="thm-btn" type="submit"><i class="far fa-paper-plane"></i> Envoyer</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact end -->

            <!-- Section Slogan -->
<section style="background-color: #f0f0f0; padding: 40px; text-align: center;">
    <h2 style="color: #333; font-size: 2rem; margin: 0;">MATE ENGINEERING</h2>
    <p style="color: #666; font-size: 1.2rem;">La norme de l'électrotechnique</p>
</section>


           
        </main>

        <?php
    include("footer.php")
    ?>