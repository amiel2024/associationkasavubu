<?php
    include("header.php")
    ?>

        <main>
            <!-- page title area start -->
            <section class="page-title-area pt-160 pb-160" data-overlay="8" data-background="img/bg/page-title-bg.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="page-title text-center">
                                <div class="border-title">
                                    <h1>Contact</h1>
                                </div>
                                <h1>Contact us</h1>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb justify-content-center">
                                        <li class="breadcrumb-item">
                                            <a href="index.php">Accueil</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">Contact</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- page title area end -->

            <!-- contact start -->
            <section class="contact-area gray-bg pt-120 pb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-9 col-lg-9 col-md-8">
                            <div class="contact-form mb-40">
                                <h3>Contactez-nous</h3>
                                <form action="#">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <input type="text" placeholder="Your Name">
                                        </div>
                                        <div class="col-xl-6">
                                            <input type="text" placeholder="Your Mail">
                                        </div>
                                        <div class="col-xl-12">
                                            <textarea name="message" cols="30" rows="10" placeholder="Your Massage"></textarea>
                                            <button class="thm-btn" type="submit">Envoyer</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4">
                            <div class="contact-info mb-40">
                                <h3>Contact Details</h3>
                                <ul>
                                    <li>
                                        <div class="contact right-info">
                                            <div class="c-right-icon">
                                                <span><i class="fas fa-map-marker-alt"></i></span>
                                            </div>
                                            <div class="c-right-text">
                                                <p>Siège social : 32, Av. Ntambwe Matheus Joli Site Q/ Manike Ville de Kolwezi. RDC.
</p>
                                                
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="contact right-info">
                                            <div class="c-right-icon">
                                                <span><i class="fas fa-phone-alt"></i></span>
                                            </div>
                                            <div class="c-right-text">
                                                <p>+243 850 602 565 
</p>
                                              
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="contact right-info">
                                            <div class="c-right-icon">
                                                <span><i class="far fa-envelope"></i></span>
                                            </div>
                                            <div class="c-right-text">
                                                <p>contact@mateengineering.cd</p>
                                            
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact end -->

            
        </main>

        <?php
    include("footer.php")
    ?>