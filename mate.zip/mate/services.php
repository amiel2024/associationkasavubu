<?php
    include("header.php")
    ?>

        <main>
            <!-- page title area start -->
            <section class="page-title-area pt-160 pb-160" data-overlay="8" data-background="img/bg/page-title-bg.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="page-title text-center">
                                <div class="border-title">
                                    <h1>Services</h1>
                                </div>
                                <h1>Nos Services</h1>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb justify-content-center">
                                        <li class="breadcrumb-item">
                                            <a href="index.php">Accueil</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">Services</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- page title area end -->

             <!-- services start -->
            <section class="services-area gray-bg pt-120 pb-90">
                <div class="container">
                    <div class="section-title text-center">
                        <div class="border-title">
                            <h1>Services</h1>
                        </div>
                        <h5>Nos </h5>
                        <h2>Services</h2>
                    </div>
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                  <h2>Maintenance des équipements électriques</h2>
                                    <p>La vente de services de maintenance des équipements électriques, automation et mécaniques.</p>


                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box active text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Construction</h2>
                                    <p>La construction, la réhabilitation des bâtiments et la fourniture des équipements industriels.</p>


                                    <a class="sevices-btn" href="services.php">Lire plus<i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Electricté des batiments</h2>
                                    <p>L’électricité de bâtiments et industrielle, et la mise en place du système électronique de sécurisation de maisons, 
                                        sites et entreprises.</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Débroussaillage des lignes électriques</h2>
                                    <p>  Les lignes haute et basse tension, 
 Les servitudes électriques en milieux urbains et ruraux, 
 Les zones sensibles aux risques d’incendie ou de coupure de courant</p>
</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2> Le froid en général</h2>
                                    <p>Installation de systèmes frigorifiques : chambres froides, vitrines réfrigérées, congélateurs industriels, etc.

Entretien et dépannage : maintenance préventive et corrective pour garantir la performance et la durabilité de vos équipements.</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Flottation des minerais</h2>
                                    <p>	L'entretien des équipements de concassage et flottation des minerais. Diagnostic et intervention rapide pour réduire les arrêts de production et maximiser le rendement des installations. </p>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Montage des meubles</h2>
                                    <p>La fourniture des bureaux et montage des meubles. Mobilier de qualité : bureaux, chaises, armoires, tables de réunion, rangements, etc.

Montage sur site : assemblage rapide et soigné, avec respect des plans et consignes techniques.</p>
</p>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6">
                            <div class="services-box text-center mb-30">
                                <div class="services-box-thumb mb-25">
                                    <img src="img/icon/s06.png" alt="image_not_found">
                                </div>
                                <div class="services-box-text">
                                    <h2>Fourniture des matériels électriques</h2>
                                    <p>	La vente et la fourniture des matériels électriques. Fourniture rapide : disponibilité constante, livraison sur site, et accompagnement dans le choix des équipements.

Conseil technique : assistance pour garantir la conformité.</p>
</p>
                                    
                                </div>
                            </div>
                        </div>

                       
                    </div>
                </div>
            </section>
            <!-- services end -->

            <?php
    include("footer.php")
    ?>