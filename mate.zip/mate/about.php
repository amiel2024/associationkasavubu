<?php
    include("header.php")
    ?>
        <main>
            <!-- page title area start -->
            <section class="page-title-area pt-160 pb-160" data-overlay="8" data-background="img/bg/page-title-bg.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="page-title text-center">
                                <div class="border-title">
                                    <h1>A propos</h1>
                                </div>
                                <h1>A propos</h1>
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb justify-content-center">
                                        <li class="breadcrumb-item">
                                            <a href="index.php">Accueil</a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">A propos de nous</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- page title area end -->
 <!-- about start -->
            
 <section class="about-area pb-90 pt-5" id="about">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="about-tab">
                                <nav>
                                    
                                </nav>

                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade" id="nav-01" role="tabpanel" aria-labelledby="nav-01-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos !</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>

                                                        <p>Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction. Elle intervient principalement dans les domaines de l’électricité, de la mécanique, de l’automation, de la construction, ainsi que dans la fourniture d’équipements industriels.

L’entreprise offre des services de maintenance et d'installation pour les équipements électriques, la réhabilitation de bâtiments, la sécurisation électronique de sites (maisons, entreprises), et s’engage également dans le débroussaillage des lignes électriques et la gestion du froid industriel. Elle dispose aussi de compétences dans le concassage et la flottation des minerais, montrant une forte expertise dans le secteur minier.

En complément, elle propose la vente et le montage de mobiliers de bureau ainsi que la fourniture de matériels électriques, faisant d’elle un acteur polyvalent et stratégique pour tout projet technique, industriel ou logistique.

Basée à Kolwezi, au cœur du Lualaba en République Démocratique du Congo,Mate Engineering  s’inscrit dans une dynamique de développement local et vise à répondre aux besoins croissants des secteurs industriels, miniers et immobiliers dans la région.</p>
                              
                                                               
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>10<span>+</span></h1>
                                                            <h5>Années</h5>
                                                            <h3>d'Expérience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade show active" id="nav-02" role="tabpanel" aria-labelledby="nav-02-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos !</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>
                                                        <p>Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction. Elle intervient principalement dans les domaines de l’électricité, de la mécanique, de l’automation, de la construction, ainsi que dans la fourniture d’équipements industriels.</br></br>

L’entreprise offre des services de maintenance et d'installation pour les équipements électriques, la réhabilitation de bâtiments, la sécurisation électronique de sites (maisons, entreprises), et s’engage également dans le débroussaillage des lignes électriques et la gestion du froid industriel. Elle dispose aussi de compétences dans le concassage et la flottation des minerais, montrant une forte expertise dans le secteur minier.</br></br>

En complément, elle propose la vente et le montage de mobiliers de bureau ainsi que la fourniture de matériels électriques, faisant d’elle un acteur polyvalent et stratégique pour tout projet technique, industriel ou logistique.

Basée à Kolwezi, au cœur du Lualaba en République Démocratique du Congo,Mate Engineering  s’inscrit dans une dynamique de développement local et vise à répondre aux besoins croissants des secteurs industriels, miniers et immobiliers dans la région.</p>
                                                    
                                                       
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>10<span>+</span></h1>
                                                            <h5>années</h5>
                                                            <h3>d'expérience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-03" role="tabpanel" aria-labelledby="nav-03-tab">
                                        <div class="about-wrapper pt-120">
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="about-left pos-rel">
                                                        <div class="border-title-2">
                                                            <h1>A Propos</h1>
                                                        </div>
                                                        <div class="about-title mb-20">
                                                            <h5>A propos</h5>
                                                            <h2>Nous croyons à la puissance de grandes idées<span>.</span></h2>
                                                        </div>

                                                        <p>JAGUAR GROUP HOLDING est un conglomérat international structuré autour 
                                                            de plusieurs pôles d’activité stratégiques, incarnant puissance, innovation
                                                             et excellence. Avec une vision à long terme et un engagement fort envers la
                                                              performance durable, le groupe fédère des filiales spécialisées, chacune leader
                                                               dans son secteur.</p>

                                                     
                                                               <ul class="about-info mt-30 mb-30">
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Equipe dynamique</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Expérience démontrée</h5>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="about-info-title">
                                                                    <span><i class="fas fa-check"></i></span>
                                                                    <h5>Qualité guarantie</h5>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                        <div class="about-btn pt-20">
                                                            <a href="about.php" class="thm-btn">Découvrir</a>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="about-right pos-rel">
                                                        <div class="about-right-content">
                                                            <h1>29<span>+</span></h1>
                                                            <h5>Years</h5>
                                                            <h3>of Experience</h3>
                                                        </div>
                                                        <div class="about-right-thumb">
                                                            <img src="img/bg/about-bg.png" alt="image_not_found">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about end -->

            
            <!-- Section Slogan -->
<section style="background-color: #f0f0f0; padding: 40px; text-align: center;">
    <h2 style="color: #333; font-size: 2rem; margin: 0;">Mate Engineering</h2>
    <p style="color: #666; font-size: 1.2rem;">La norme de l'électrotechnique!</p>
</section>
        </main>

        <?php
    include("footer.php")
    ?>