
        


<!-- footer start -->
<footer>
    <div class="footer-area footer-2 footer-height pt-100 pb-40" style="background-color: black;">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="footer-left-widget f-left-widget-2 mb-40">
                        <div class="footer-logo">
                            <img src="img/logo/logo-02.png" alt="logo_not_found">
                        </div>
                        <p style="color: white;">
                            Mate Engineering est une société spécialisée dans les services techniques et industriels, avec un large éventail d’activités allant de la maintenance à la construction. Elle intervient principalement dans les domaines de l’électricité, de la mécanique, de l’automation, de la construction, ainsi que dans la fourniture d’équipements industriels.
                        </p>
                        <div class="f-left-bottom mt-25"></div>
                    </div>
                </div>
                <div class="col-xl-2 offset-xl-1 col-lg-6 col-md-6 pr-0">
                    <div class="footer-widget footer-link">
                        <h3 style="color: white;">Liens rapides</h3>
                        <ul>
                            <li><a href="index.php" style="color: white;">Accueil</a></li>
                            <li><a href="about.php" style="color: white;">A propos</a></li>
                            <li><a href="services.php" style="color: white;">Services</a></li>
                            <li><a href="Javascript:void(0);" style="color: white;">Actualités</a></li>
                            <li><a href="contact.php" style="color: white;">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 offset-xl-1 col-lg-6 col-md-6">
                    <div class="footer-widget footer-widget-space mb-40">
                        <h3 style="color: white;">Contact</h3>
                        <ul class="footer-info">
                            <li>
                                <div class="footer-address mt-20">
                                    <span style="color: white;"><i class="fas fa-map-marker-alt"></i></span>
                                    <h5 style="color: white;">Siège social : 32, Av. Ntambwe Matheus Joli Site Q/ Manike Ville de Kolwezi. RDC.</h5>
                                </div>
                            </li>
                            <li>
                                <div class="footer-address mt-20">
                                    <span style="color: white;"><i class="fas fa-phone-alt"></i></span>
                                    <h5 style="color: white;">+243 850 602 565</h5>
                                </div>
                            </li>
                            <li>
                                <div class="footer-address mt-20">
                                    <span style="color: white;"><i class="fas fa-envelope-open-text"></i></span>
                                    <h5 style="color: white;">contact@mateengineering.cd</h5>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="copyright-area pt-20 pb-20" style="background-color: black;">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="copyright-text text-center">
                        <p style="color: white;">Copyright by @ Mate Engineering - 2025. Made by MastaGate</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer end -->


        <!-- JS here -->
        <script src="js/vendor/modernizr-3.8.0.min.js"></script>
        <script src="js/vendor/jquery-1.12.4.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/slick.min.js"></script>
        <script src="js/jquery.scrollUp.min.js"></script>
        <script src="js/jquery.meanmenu.min.js"></script>
        <script src="js/imagesloaded.pkgd.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>
    </body>

<!-- Mirrored from wasimmia.github.io/bildhub/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Jul 2023 11:10:06 GMT -->
</html>