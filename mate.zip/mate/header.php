<!doctype html>
<html class="no-js" lang="zxx">
    
<!-- Mirrored from wasimmia.github.io/bildhub/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Jul 2023 11:08:30 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Mate Engineering</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
        <!-- Place favicon.png in the root directory -->

        <!-- CSS here -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/fontawesome-all.min.css">
        <link rel="stylesheet" href="css/themify-icons.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/meanmenu.css">
        <link rel="stylesheet" href="css/slick.css">
        <link rel="stylesheet" href="css/default.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
    </head>
    <body>

        <!-- preloader start -->
        <div id="preloader">
            <div class="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- preloader end  -->

        <!-- header start -->
        <header>
            
            <div class="header-bottom-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo logo-2">
                                <a href="index.php"><img src="img/logo/logo.png" alt="logo_not_found"></a>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10">
                            <div class="header-button d-none d-lg-block f-right">
                                <a class="thm-btn" href="contact.php">Devis</a>
                            </div>
                            <div class="main-menu f-right">
                                <nav id="mobile-menu">
                                    <ul>
                                        <li><a href="index.php">Accueil</a></li>
                                        <li><a href="about.php">A propos</a></li>
                                        <li><a href="services.php">Services</a> </li>       
                                        <li><a href="Javascript:void(0);">Actualités</a> </li>      
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="mobile-menu"></div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- header end -->
